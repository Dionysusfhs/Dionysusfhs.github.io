js is quite interesting~
