JavaScript Notes
